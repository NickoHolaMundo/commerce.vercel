import requests, json


class ApiRequests:

  def __init__(self):
    self.url = "https://testing-agriglobal-market.ue.r.appspot.com/api/getproducts/admisiones"

  def re(self):
    return requests.get(url=self.url).json()['products']

  # EJEMPLO 1
  def data3x3(self):
    return [self.re()[9 * i:9 * (i + 1)] for i in range(0, l)]

  # DEVUELVE LA DATA 3X3 DEPENDIENDO DEPENDIENDO DEL _INDEX
  def data3x3Index(self, _index):
    try:
      return [self.re()[9 * _index:9 * (_index + 1)]]
    except:
      return -1  #NO CONEXION

  # CUANDO QUIERO SOLO UN DATO
  def oneData(self, _index):
    try:
      return self.re()[_index]
    except:
      return -1  #NO CONEXION

  def category(self):
    try:
      re = self.re()
      for i in re:
        # print(i['category'])
        return i['category']
    except:
      pass
