'''
pip install fastapi
pip install "uvicorn[standard]"

RUN
uvicorn main:app --reload
'''

#from pydantic import BaseModel
from typing import Optional
import warnings
import logging
import json, asyncio, time

from fastapi import FastAPI, Form, Request, status, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import uvicorn

from ariglobal.Ariglobal import ApiRequests
'''ariglobal

python main.py


'''

warnings.filterwarnings("ignore")
app = FastAPI()

api = ApiRequests()

app.mount("/static", StaticFiles(directory="static"), name="static")

templates = Jinja2Templates(directory="templates")


@app.get("/index", response_class=HTMLResponse)
async def index(request: Request):
  print("items")
  return templates.TemplateResponse("index.html", {
    "request": request,
    "id": id
  })


# link : http://localhost:8080/
@app.get("/")
async def read():
  return {"Hello": "World"}


# data 3x3 con index
# link : http://localhost:9090/dataGroup?_index=1
@app.get("/dataGroup", status_code=status.HTTP_200_OK)
async def read(_index: int):
  # return api.data3x3()
  data = api.data3x3Index(_index)
  if data != -1:
    return {"Response": data}
  return {"Error": "No requests"}


# devuelve 1 data json dependiendo del index
# http://localhost:9090/OneData?_index=1
@app.get("/OneData", status_code=status.HTTP_200_OK)
async def read(_index: int):
  data = api.oneData(_index)
  if data != -1:
    return {"Response": data}
  return {"Error": "No requests"}


logger = logging.getLogger("uvicorn.error")
logger.propagate = False
try:
  uvicorn.run(app, host="0.0.0.0", port="8080")
except:
  pass
